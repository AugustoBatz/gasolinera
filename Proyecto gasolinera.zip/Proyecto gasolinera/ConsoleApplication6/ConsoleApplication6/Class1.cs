﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Menus
    {
        Program c3 = new Program();

        Depositos dep = new Depositos();
     
        public int mp, mb,md;

        public void menuprincipal()
        {
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("                     Bienvendio a la gasolinera pacman :’v ");
            Console.WriteLine("                     Elija una opcion         ");
            Console.WriteLine("                     1.Llenar depositos");
            Console.WriteLine("                     2.Comprar Gasolina");
            Console.WriteLine("                     3.Salir");
            Console.WriteLine("                     4.Estadistica");
            Console.WriteLine("");
            mp = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
        }
        public void menudepositos()
        {
            Console.WriteLine("");
            Console.WriteLine("Que deposito desea ingresar");
            Console.WriteLine("1.Deposito de diesel");
            Console.WriteLine("2.Deposito de regular");
            Console.WriteLine("3.Deposito de super");
            Console.WriteLine("4.Regresar");
            Console.WriteLine("");
            Console.WriteLine("5.Promedios por galon y asignar precios");
            Console.WriteLine("");
            
           
        }
        public void comopagar()
        {
            
         
            Console.WriteLine("Como quiere consumir:");
            Console.WriteLine("1.Por galon");
            Console.WriteLine("2.Cantidad de dinero");
            Console.WriteLine("");
        }
        public void bombas()
        {
            Console.WriteLine("        A que bomba desea ingresar:");
            Console.WriteLine("");
            Console.WriteLine("                 Bomba1");
            Console.WriteLine("");
            Console.WriteLine("                 Bomba2");
            Console.WriteLine("");
            Console.WriteLine("                 Bomba3");
            Console.WriteLine("");
            Console.WriteLine("                 Bomba4");
            Console.WriteLine("");
            Console.WriteLine("5.Regresar");
            Console.WriteLine("");
            
        }
        public void bom()
        {
            Console.WriteLine("Bienvenido a la bomba ");
            Console.WriteLine("Que desea consumir");
            Console.WriteLine("1.Disiel");
            Console.WriteLine("2.Regular");
            Console.WriteLine("3.Super");
            Console.WriteLine("4.Regresar");
            Console.WriteLine("");
             

        }
     
    


    }
}
