﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Depositos
    {
        
        Program c = new Program();
        public double depositodi = 10;
        public double depositoreg = 10;
        public double depositosup = 10;
        public double costodepd, costodepreg, costodeps;
        public int bm1=0;
        public double cost = 0;
       



        public void mostrar()
        {
            Console.WriteLine("Los depositos cuentan con: ");
            Console.WriteLine(+depositodi+" galones de disiel, a un precio inical de 10xgalon");
            Console.WriteLine(+depositoreg + " galones de regular, a un precio inical de 12xgalon");
            Console.WriteLine(+depositosup + " galones de super, a un precio inical de 15xgalon");
            
        }
      
        }
       
        
        
       
     


    }

