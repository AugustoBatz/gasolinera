﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Program
    {
        public double preciodefidis = 10;//precios definido al principo de cada tipo de comustible, definidio mas adelante
        public double preciodefisup=15;
        public double preciodefireg=12;
        public double Totaldegal1bomba, Totaldegal2bomba, Totaldegal3bomba,Totaldegal4bomba;//variables para calcular el total de galones vendidos por cada bomba
        public double TotaldeInl1bomba, TotaldeInl2bomba, TotaldeInl3bomba, TotaldeInl4bomba; //varibles para el total de ingresos por cada bomba
        public int galind, galinr, galins;
        public double tg1d, tg1s, tg1r, tg2d, tg2s, tg2r, tg3d, tg3s, tg3r, tg4d, tg4s, tg4r;//variables para el total de galones de cada bomba vendidos 
        public double galdined, galdiner, galdines, totalgastd, totalgastr, totalgasts;//variables para los gastos de compra de combustible al llenar los depositos
        public double ga1d, ga1s, ga1r, ga2d, ga2s, ga2r, ga3d, ga3s, ga3r, ga4d, ga4s, ga4r;//dinero gasta al consumir por galones
        public double vgalonestotalesdis, vgalonestotalesup, vgalonestotalesreg;//galones total vendidos de cada tipo de combustible
        public double ingresossuper, ingresosdisiel, ingresosregular;//dinero ingresado por cada tipo de combustible
        public double ganancias;//variable para las ganancias
        public double gax1cdis, gax1creg, gax1csup, gax2cdis, gax2creg, gax2csup, gax3cdis, gax3creg, gax3csup, gax4cdis, gax4creg, gax4csup;//galones vendidos por consumo por dinero 
        public double con1sudidis, consudi1sup, consudi1reg, con2sudidis, consudi2sup, consudi2reg, con3sudidis, consudi3sup, consudi3reg, con4sudidis, consudi4sup, consudi4reg;//variables por consumo de diner por bomba y tipo de combustible(individial)
        public double costoid = 10;// cosot inciales de cada combustible
        public double costoir = 12;
        public double costois = 15;
        public double Costoactd, Costoactr, Costoacts; //varibles para el costo actual de cada combustible
        
        public int ngd, ngr, ngs;//galones ingresado al deposito
        static void Main(string[] args)
        {



            int submenus;
            
           
            Program c = new Program();//se declara el objeto para el uso de todas las variables que se encuentran afuera de esta clase
            Depositos d = new Depositos();//se declara el objeto depositos
            Menus m1 = new Menus();//se declara el objeto para menus
            d.costodepd = 10 * 10;//dinero gasta por los 10 galones previos
            d.costodepreg = 10 * 12;
            d.costodeps = 10 * 15;



           
        principal2://etiqueta para retornar



            try//para opciones invalidas
            {
                m1.menuprincipal();//llama al procemiento para desplegar el menu principal
            }
            catch//para opciones invalidas
            {
                Console.WriteLine("opcion invalida");
                Console.ReadLine();
                Console.Clear();
                goto principal2;//retorna a la etiqueta


            }
            switch (m1.mp)//incio del switch para elegir una opcion del menu principal
            {
                case 1://llenar combusibtle
                principal:
                    d.mostrar();
                    m1.menudepositos();//llama al menu de la clase menus
                    

                    try
                    {
                    pri3:
                        submenus = Convert.ToInt32(Console.ReadLine());//guarda la opcion indicada por el administrador
                    Console.Clear();
                        switch (submenus)
                        {
                            case 1:// ingreso de galones al depostio del disiel
                            etiqueta1:
                                Console.WriteLine("Cuantos Galones desea ingresar de Disiel");
                                c.galind = Convert.ToInt32(Console.ReadLine());//guarda la cantidad de galones
                                
                                   
                                   c.ngd  = c.ngd + c.galind;//la variable c.ngd esta en constante cambio ya que acumula los galones que se ingresen al deposito
                                Console.WriteLine("Cuanto cuesta cada galon"); 
                                c.galdined = Convert.ToDouble(Console.ReadLine());//guarda el precio de compra por galones
                                if ((c.galind >= 0) && (c.galind <= 40))//hace la comparacion para ver si los galones que se quieren ingresar no sobre pasan la capacidad del depostio
                                {   
                                    c.totalgastd = c.totalgastd + (c.galind * c.galdined);//guarda lo gastado por el ingreso de depostios, tambien acumula los gastos
                                    c.Costoactd = (100 + c.totalgastd) / (10 + c.ngd);//saca el promedio ponderado
                                    Console.WriteLine("El total gastado es " + c.galind * c.galdined + " quetzales ");//muestra lo gastado

                                    d.depositodi = d.depositodi + c.galind;//llena el depostio, tambien acumula los galones ingresados
                                    if (d.depositodi >= 51)//condicion por si los galones sobre pasan la capacidada del depostio
                                    {
                                        Console.WriteLine("El depostio se llena, vuelva a ingresar una cantidad valida");//si se sobre pasa le muestra un mensaje al usuario que el depostio se llena
                                        Console.ReadLine();                                                              //y lo regresa para que ingrese una cantidad valida
                                        goto principal;
                                    }
                                    Console.WriteLine("El deposito tiene " + d.depositodi + " galones" );//le muestra al admin con cuantos galones esta el deposito
                                    
                                    Console.ReadLine();
                                    Console.Clear();
                                    goto principal;
                                }
                                else
                                {
                                    double dis = 0;
                                    dis = 50 - d.depositodi;
                                    Console.WriteLine("El deposito se llena el espacio disponible son " + dis + " galones");

                                    goto etiqueta1;// ir a la etiqueta regresar si galr es mayo a 40


                                }//fin case 1


                            case 2: //inicio case sub 2
                            etiqueta2:
                                Console.WriteLine("Cuantos Galones desea ingresar de regular");
                                c.galinr = Convert.ToInt32(Console.ReadLine());
                                c.ngr  = c.ngr + c.galinr;
                                Console.WriteLine("Cuanto cuesta cada galon");
                                c.galdiner = Convert.ToDouble(Console.ReadLine());
                                if ((c.galinr >= 0) && (c.galinr <= 40))
                                {
                                    c.totalgastr = c.totalgastr + (c.galinr * c.galdiner);
                                    c.Costoactr = (120 + c.totalgastr) / (12 + c.ngr);
                                    Console.WriteLine("El total gastado es " + c.galinr*c.galdiner + " quetzales ");

                                    d.depositoreg = d.depositoreg + c.galinr;
                                    if (d.depositoreg >= 51)
                                    {
                                        Console.WriteLine("El depostio se llena, vuelva a ingresar una cantidad valida");
                                        Console.ReadLine();
                                        goto etiqueta1;
                                    }
                                    Console.WriteLine("El deposito tiene " + d.depositoreg + " galones");
                                    Console.ReadLine();
                                    Console.Clear();
                                    goto principal;
                                }
                                else
                                {
                                    double dis = 0;
                                    dis = 50 - d.depositoreg;
                                    Console.WriteLine("El deposito se llena el espacio disponible son " + dis + " galones");

                                    goto etiqueta2;// ir a la etiqueta regresar si galr es mayo a 40


                                }// fin case sub 2
                            case 3: //inicio case sub 3
                            etiqueta3:
                                Console.WriteLine("Cuantos Galones desea super");
                                c.galins = Convert.ToInt32(Console.ReadLine());
                                c.ngs  = c.ngs + c.galins;
                                Console.WriteLine("Cuanto cuesta cada galon");
                                c.galdines = Convert.ToDouble(Console.ReadLine());
                                if ((c.galins >= 0) && (c.galins <= 40))
                                {
                                    c.totalgasts = c.totalgasts + (c.galins * c.galdines);
                                    c.Costoacts = (150 + c.totalgastr) / (15 + c.ngs);
                                    Console.WriteLine("El total gastado es " + c.galins*c.galdines + " quetzales ");
                                  

                                    d.depositosup = d.depositosup + c.galins;
                                    if (d.depositosup >= 51)
                                    {
                                        Console.WriteLine("El depostio se llena, vuelva a ingresar una cantidad valida");
                                        Console.ReadLine();
                                        goto etiqueta1;
                                    }
                                    Console.WriteLine("El deposito tiene " + d.depositosup + " galones");
                                    Console.ReadLine();
                                    Console.Clear();
                                    goto principal;
                                }
                                else
                                {
                                    double dis = 0;
                                    dis = 50 - d.depositosup;
                                    Console.WriteLine("El deposito se llena el espacio disponible son " + dis + " galones");

                                    goto etiqueta3;// ir a la etiqueta regresar si galr es mayo a 40


                                }// fin case sub 3
                            case 4:
                                Console.Clear();
                                goto principal2;
                            default:
                                Console.WriteLine("opcion invalida");

                                Console.Clear();
                                goto pri3;

                            case 5://opcion 5 para mostrar el promedio ponderado de cada combustible
                                Console.WriteLine("El precio promedio por galon son:");
                                Console.WriteLine("Disiel : "+c.Costoactd+ " por galon");
                                Console.WriteLine("Regular : "+c.Costoactr+ " por galon");
                                Console.WriteLine("Super : "+c.Costoacts+ " por galon");
                                Console.WriteLine("Pulse 0 para regresar, si los promedios estan en 0,");
                                Console.WriteLine("Por favor llene los depositos");
                                Console.WriteLine("");
                                Console.WriteLine("Si desea definir los precios pulse 1");
                                int regre;//variable local para la condicion
                                regre = Convert.ToInt32(Console.ReadLine());//guarda el valor 
                                
                                if (regre==0)//condicion para regresar al menu anterior
                                {
                                    Console.Clear();
                                    goto principal;
                                }
                                if (regre == 1)//condicion para desplegar el menu para definir precios
                                {
                                    
                                    int sb;
                                Regresar2:
                                    
                                    Console.WriteLine("Definir precios");//menu para definir precios
                                    Console.WriteLine("1.Disiel");
                                    Console.WriteLine("2.Super");
                                    Console.WriteLine("3.Regular");
                                    Console.WriteLine("4.Regresar ");


                                    sb = Convert.ToInt32(Console.ReadLine());//guarda los casos para el siguiente switch
                                    Console.Clear();
                                    switch (sb)//switch para definir precios
                                    {
                                        case 1://inicio case 1 para definri el precio del disiel
                                        Regresar1:
                                            Console.WriteLine("A cuanto quiere que se venda el Disiel ");
                                             
                                            c.preciodefidis = Convert.ToDouble(Console.ReadLine());//precio definidio disiel esta variable se usa para mostrar el precio para el cliente
                                            Console.Clear();
                                            if (c.preciodefidis < c.Costoactd) //hace la comparacio si el precio ingresado no se menor al precio promedio
                                            {//al si es menor le muestra que tendra perdidas y lo regresa para recalcular el precio definido
                                                int res;
                                                Console.WriteLine("Usted tendra perdidas");
                                                Console.WriteLine("Desea poner un nuevo precio?");
                                                Console.WriteLine("1.SI");
                                                Console.WriteLine("2.Regrear");
                                                res = Convert.ToInt32(Console.ReadLine());
                                                if (res == 1)
                                                {
                                                    Console.Clear();
                                                    goto Regresar1;
                                                }
                                                if (res == 2)
                                                {
                                                    if (c.preciodefidis < 0)//por si se le ocurre ingresar un numero negativo 
                                                    {
                                                        Console.WriteLine("Usted ingreso un numero negativo intente de nuevo");
                                                        Console.ReadLine();
                                                        Console.Clear();
                                                        goto Regresar1;
                                                    }
                                                   
                                                    Console.Clear();
                                                    goto Regresar2;
                                                }
                                                else
                                                {
                                                    Console.WriteLine("Error");
                                                    Console.ReadLine();
                                                    Console.Clear();
                                                    goto Regresar2;
                                                }
                                            }
                                                
                                        else
                                            {
                                                Console.WriteLine("Hesta hecho");
                                                Console.WriteLine("Precio definidio por galon es " + c.preciodefidis);//le muetra el precio definido
                                                Console.ReadLine();
                                                Console.Clear();
                                            }
                                            break; //fin case 1
                                        case 2://inicio case 1
                                        Regresar3:
                                            Console.WriteLine("A cuanto quiere que se venda el Super");

                                            c.preciodefisup = Convert.ToDouble(Console.ReadLine());//precio definido super
                                            Console.Clear();
                                            if (c.preciodefisup < c.Costoacts)
                                            {
                                                int res2;
                                                Console.WriteLine("Usted tendra perdidas");
                                                Console.WriteLine("Desea poner un nuevo precio?");
                                                Console.WriteLine("1.SI");
                                                Console.WriteLine("2.Regrear");
                                                res2 = Convert.ToInt32(Console.ReadLine());
                                                if (res2 == 1)
                                                {
                                                    Console.Clear();
                                                    goto Regresar3;
                                                }
                                                if (res2 == 2)

                                                {
                                                    if (c.preciodefisup < 0)
                                                    {
                                                        Console.WriteLine("Usted ingreso un numero negativo intente de nuevo");
                                                        Console.ReadLine();
                                                        Console.Clear();
                                                        goto Regresar3;
                                                    }
                                                    Console.Clear();
                                                    goto Regresar2;
                                                }
                                                else
                                                {
                                                    Console.WriteLine("Error");
                                                    Console.ReadLine();
                                                    Console.Clear();
                                                    goto Regresar2;
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine("Hesta hecho");
                                                Console.WriteLine("Precio definidio por galon es " + c.preciodefisup);
                                                Console.ReadLine();
                                                Console.Clear();
                                            }
                                            break;
                                        case 3:
                                        Regresar4:
                                            Console.WriteLine("A cuanto quiere que se venda el Regular");

                                            c.preciodefireg = Convert.ToDouble(Console.ReadLine());//precio definido regular
                                            Console.Clear();
                                            if (c.preciodefireg < c.Costoactr)
                                            {
                                                int res3;
                                                Console.WriteLine("Usted tendra perdidas");
                                                Console.WriteLine("Desea poner un nuevo precio?");
                                                Console.WriteLine("1.SI");
                                                Console.WriteLine("2.Regrear");
                                                res3 = Convert.ToInt32(Console.ReadLine());
                                                if (res3 == 1)
                                                {
                                                    Console.Clear();
                                                    goto Regresar4;
                                                }
                                                if (res3 == 2)
                                                {
                                                    if (c.preciodefireg < 0)
                                                    {
                                                        Console.WriteLine("Usted ingreso un numero negativo intente de nuevo");
                                                        Console.ReadLine();
                                                        Console.Clear();
                                                        goto Regresar4;
                                                    }
                                                    Console.Clear();
                                                    goto Regresar2;
                                                }
                                                else
                                                {
                                                    Console.WriteLine("Error");
                                                    Console.ReadLine();
                                                    Console.Clear();
                                                    goto Regresar2;
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine("Hesta hecho");
                                                Console.WriteLine("Precio definidio por galon es " + c.preciodefireg);
                                                Console.ReadLine();
                                                Console.Clear();
                                            }
                                            break;


                                    }         
                                    goto principal;
                                }
                                
                                
                                break;
                        }

                    }
                    catch
                    {
                        Console.WriteLine("opcion invalida");
                        Console.ReadLine();
                        Console.Clear();
                        goto principal;


                    }

                    break;// fin sub case principal 1  
                    case 2://incio case del cliente
                    
                    int sbs;
                    back3:
                    try
                    { 
                        
                        m1.bombas();//muestra el menu de las 4 bombas
                        sbs = Convert.ToInt32(Console.ReadLine());//varible para el switch
                        Console.Clear();
                        }
                    catch
                    {
                        Console.WriteLine("opcion invalida");
                        Console.ReadLine();
                        Console.Clear();
                        goto back3;
                    }
                    try
                    {
                        switch (sbs)//inicio sub case de bombas
                        {

                                //primera bomba
                            case 1://case bomba 1
                                int st;
                            back2://encabezado que muestra el precio de los combustibles y los galones que tiene cada depostito
                                Console.WriteLine("Los precios de cada combustible son");
                                Console.WriteLine("Disiel " + c.preciodefidis + " por galon");
                                Console.WriteLine("Regular " + c.preciodefireg + " por galon");
                                Console.WriteLine("Super " + c.preciodefisup + " por galon");
                                Console.WriteLine("Los depositos cuentan con: ");
                                Console.WriteLine(d.depositodi + " galones de disiel");
                                Console.WriteLine(d.depositoreg + " galones de regular");
                                Console.WriteLine(d.depositosup + " galones de super");
                                Console.WriteLine("");
                                m1.bom();// menu para preguntarle que tipo de combustible desea consumir
                                Console.WriteLine("");
                                st = Convert.ToInt32(Console.ReadLine());//variable para el switch
                                switch (st) //inicio 2 sub case
                                {
                                    case 1:// case disiel      
                                        //proceso para comprar disiel en la bomba 1
                                        int resp;
                                        m1.comopagar();// menu que muestra como quiere pagar
                                        resp = Convert.ToInt32(Console.ReadLine());
                                        if (resp == 1)// descision de comprar por galones
                                        {
                                            int compra1dise = 0;
                                            double gasto1dise = 0;
                                            Console.WriteLine("Cuantos galones desea comprar");
                                            compra1dise = Convert.ToInt32(Console.ReadLine());// guarda los galones que quiere comprar el usuario
                                            if (compra1dise > d.depositodi)// condicion si no se cuenta con los galones en el deposito
                                            {//muestra un mensaje diciendo que no se cuenta con esa cantida de galones y lo regresa a donde estaba
                                                Console.WriteLine("Lo sentimos no contamos con es cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back2;
                                            }
                                            c.tg1d = c.tg1d + compra1dise;//guarda constanstemente el total gastado por galones de disel bomba1
                                            d.depositodi = d.depositodi - compra1dise;//le resta al depostio los galones vendidos
                                            gasto1dise = compra1dise * c.preciodefidis;//gasto que hizo el cliente
                                            c.ga1d = c.ga1d + gasto1dise;//va acumulando los ingresos de la bomba1
                                            Console.WriteLine("Usted gasto " + gasto1dise + " quetzales");//muestra al cliente lo que gasto
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back2;
                                        }
                                        if (resp == 2)//condicion si desea consumir por dinero
                                        {
                                            double consudin1d, galconsu1di;// variables consumo por dinero bomba 1 disel y galones consumidos de disel 
                                            Console.WriteLine("Cuanto desea gastar");
                                            consudin1d = Convert.ToDouble(Console.ReadLine());
                                            galconsu1di = consudin1d / c.preciodefidis;//hace la equivalencia de lo que quiere gasta entre el precio definido
                                            
                                            if (galconsu1di > d.depositodi)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con esa cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back2;
                                            }
                                            d.depositodi = d.depositodi - galconsu1di;//le resta los galones al deposito
                                            c.gax1cdis = c.gax1cdis + galconsu1di;//guarda los galones vendidos por consumo de dinero
                                            c.con1sudidis = c.con1sudidis + consudin1d;//guarda el total gastado 
                                            Console.WriteLine("Usted compro " + galconsu1di + " galones");//muestra cuanto gasto

                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back2;
                                        }
                                        else
                                        {
                                            Console.WriteLine("opcion invalida");
                                            Console.Clear();
                                            goto back2;
                                        }//final case disiel


                                    case 2:// case regu     
                                        int resp2;
                                        m1.comopagar();
                                        resp2 = Convert.ToInt32(Console.ReadLine());
                                        if (resp2 == 1)//all descision de comprar por galones
                                        {
                                            int compra1dise = 0;
                                            double gasto1dise = 0;
                                            Console.WriteLine("Cuantos galones desea comprar");
                                            compra1dise = Convert.ToInt32(Console.ReadLine());
                                            if (compra1dise > d.depositoreg)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con es cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back2;
                                            }
                                            c.tg1r = c.tg1r + compra1dise;
                                            d.depositoreg = d.depositoreg - compra1dise;
                                            gasto1dise = compra1dise * c.preciodefireg;
                                            c.ga1r = c.ga1r + gasto1dise;
                                            Console.WriteLine("Usted gasto " + gasto1dise + " quetzales");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back2;
                                        }
                                        if (resp2 == 2)//condicion sid desea consumir por dinero
                                        {
                                            double consudin1d = 0;
                                            double galconsu1di = 0;// consumo por dinero bomba 1 disel y galones consumidos de disel 
                                            Console.WriteLine("Cuanto desea gastar");
                                            consudin1d = Convert.ToDouble(Console.ReadLine());
                                            galconsu1di = consudin1d / c.preciodefireg;
                                           
                                            if (galconsu1di > d.depositoreg)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con esa cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back2;
                                            }
                                            d.depositoreg = d.depositoreg - galconsu1di;
                                            c.gax1creg = c.gax1creg + galconsu1di;
                                            c.consudi1reg = c.consudi1reg + consudin1d;
                                            Console.WriteLine("Usted compro " + galconsu1di + " galones");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back2;
                                        }
                                        else
                                        {
                                            Console.WriteLine("opcion invalida");
                                            Console.Clear();
                                            goto back2;
                                        }//final case regu
                                    case 3:// case super    
                                        int resp3;
                                        m1.comopagar();
                                        resp3 = Convert.ToInt32(Console.ReadLine());
                                        if (resp3 == 1)//all descision de comprar por galones
                                        {
                                            int compra1dise = 0;
                                            double gasto1dise = 0;
                                            Console.WriteLine("Cuantos galones desea comprar");
                                            compra1dise = Convert.ToInt32(Console.ReadLine());
                                            if (compra1dise > d.depositosup)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con es cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back2;
                                            }
                                            c.tg1s = c.tg1s + compra1dise;
                                            d.depositosup = d.depositosup - compra1dise;
                                            gasto1dise = compra1dise * c.preciodefisup;
                                            c.ga1s = c.ga1s + gasto1dise;
                                            Console.WriteLine("Usted gasto " + gasto1dise + " quetzales");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back2;
                                        }
                                        if (resp3 == 2)//condicion sid desea consumir por dinero
                                        {
                                            double consudin1d = 0;
                                            double galconsu1di = 0;// consumo por dinero bomba 1 disel y galones consumidos de disel 
                                            Console.WriteLine("Cuanto desea gastar");
                                            consudin1d = Convert.ToDouble(Console.ReadLine());
                                            galconsu1di = consudin1d / c.preciodefisup;
                                       
                                            if (galconsu1di > d.depositosup)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con esa cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back2;
                                            }
                                            d.depositosup = d.depositosup - galconsu1di;
                                            c.gax1csup = c.gax1csup + galconsu1di;
                                            c.consudi1sup = c.consudi1sup + consudin1d;
                                            Console.WriteLine("Usted compro " + galconsu1di + " galones");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back2;
                                        }
                                        else
                                        {
                                            Console.WriteLine("opcion invalida");
                                            Console.Clear();
                                            goto back2;
                                        }//final case super

                                    case 4:
                                        Console.Clear();
                                        goto back3;





                                }
                                break;//final case bomba 1
                            case 2://case bomba 2
                                int st2;
                            back5:
                                Console.WriteLine("Los precios de cada combustible son");
                                Console.WriteLine("Disiel " + c.preciodefidis + " por galon");
                                Console.WriteLine("Regular " + c.preciodefireg + " por galon");
                                Console.WriteLine("Super " + c.preciodefisup + " por galon");
                                Console.WriteLine("Los depositos cuentan con: ");
                                Console.WriteLine(d.depositodi + " galones de disiel");
                                Console.WriteLine(d.depositoreg + " galones de regular");
                                Console.WriteLine(d.depositosup + " galones de super");
                                m1.bom();
                                st2 = Convert.ToInt32(Console.ReadLine());
                                switch (st2) //inicio 2 sub case
                                {
                                    case 1:// case disiel      
                                        int resp;
                                        m1.comopagar();
                                        resp = Convert.ToInt32(Console.ReadLine());
                                        if (resp == 1)//all descision de comprar por galones
                                        {
                                            int compra1dise = 0;
                                            double gasto1dise = 0;
                                            Console.WriteLine("Cuantos galones desea comprar");
                                            compra1dise = Convert.ToInt32(Console.ReadLine());
                                            if (compra1dise > d.depositodi)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con es cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back2;
                                            }
                                            c.tg2d = c.tg2d + compra1dise;//guarda constanemten total gastado galones de disel bomba1
                                            d.depositodi = d.depositodi - compra1dise;
                                            gasto1dise = compra1dise * c.preciodefidis;
                                            c.ga2d = c.ga2d + gasto1dise;
                                            Console.WriteLine("Usted gasto " + gasto1dise + " quetzales");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back5;
                                        }
                                        if (resp == 2)//condicion sid desea consumir por dinero
                                        {
                                            double consudin1d, galconsu1di;// consumo por dinero bomba 1 disel y galones consumidos de disel 
                                            Console.WriteLine("Cuanto desea gastar");
                                            consudin1d = Convert.ToDouble(Console.ReadLine());
                                            galconsu1di = consudin1d / c.preciodefidis;
                                         
                                            if (galconsu1di > d.depositodi)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con esa cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back5;
                                            }
                                            d.depositodi = d.depositodi - galconsu1di;
                                            c.gax2cdis = c.gax2cdis + galconsu1di;
                                            c.con2sudidis = c.con2sudidis + consudin1d;
                                            Console.WriteLine("Usted compro " + galconsu1di + " galones");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back5;
                                        }
                                        else
                                        {
                                            Console.WriteLine("opcion invalida");
                                            Console.Clear();
                                            goto back5;
                                        }//final case disiel


                                    case 2:// case regu     
                                        int resp2;
                                        m1.comopagar();
                                        resp2 = Convert.ToInt32(Console.ReadLine());
                                        if (resp2 == 1)//all descision de comprar por galones
                                        {
                                            int compra1dise = 0;
                                            double gasto1dise = 0;
                                            Console.WriteLine("Cuantos galones desea comprar");
                                            compra1dise = Convert.ToInt32(Console.ReadLine());
                                            if (compra1dise > d.depositoreg)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con es cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back5;
                                            }
                                            c.tg2r = c.tg2r + compra1dise;
                                            d.depositoreg = d.depositoreg - compra1dise;
                                            gasto1dise = compra1dise * c.preciodefireg;
                                            c.ga2r = c.ga2r + gasto1dise;
                                            Console.WriteLine("Usted gasto " + gasto1dise + " quetzales");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back5;
                                        }
                                        if (resp2 == 2)//condicion sid desea consumir por dinero
                                        {
                                            double consudin1d = 0;
                                            double galconsu1di = 0;// consumo por dinero bomba 1 disel y galones consumidos de disel 
                                            Console.WriteLine("Cuanto desea gastar");
                                            consudin1d = Convert.ToDouble(Console.ReadLine());
                                            galconsu1di = consudin1d / c.preciodefireg;
                                            
                                            if (galconsu1di > d.depositoreg)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con esa cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back5;
                                            }
                                            d.depositoreg = d.depositoreg - galconsu1di;
                                            c.gax2creg = c.gax2creg + galconsu1di;
                                            c.consudi2reg = c.consudi2reg + consudin1d;
                                            Console.WriteLine("Usted compro " + galconsu1di + " galones");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back5;
                                        }
                                        else
                                        {
                                            Console.WriteLine("opcion invalida");
                                            Console.Clear();
                                            goto back5;
                                        }//final case regu
                                    case 3:// case super    
                                        int resp3;
                                        m1.comopagar();
                                        resp3 = Convert.ToInt32(Console.ReadLine());
                                        if (resp3 == 1)//all descision de comprar por galones
                                        {
                                            int compra1dise = 0;
                                            double gasto1dise = 0;
                                            Console.WriteLine("Cuantos galones desea comprar");
                                            compra1dise = Convert.ToInt32(Console.ReadLine());
                                            if (compra1dise > d.depositosup)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con es cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back5;
                                            }
                                            c.tg2s = c.tg2s + compra1dise;
                                            d.depositosup = d.depositosup - compra1dise;
                                            gasto1dise = compra1dise * c.preciodefireg;
                                            c.ga2s = c.ga2s + gasto1dise;
                                            Console.WriteLine("Usted gasto " + gasto1dise + " quetzales");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back5;
                                        }
                                        if (resp3 == 2)//condicion sid desea consumir por dinero
                                        {
                                            double consudin1d = 0;
                                            double galconsu1di = 0;// consumo por dinero bomba 1 disel y galones consumidos de disel 
                                            Console.WriteLine("Cuanto desea gastar");
                                            consudin1d = Convert.ToDouble(Console.ReadLine());
                                            galconsu1di = consudin1d / c.preciodefisup;
                                           
                                            if (galconsu1di > d.depositosup)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con esa cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back5;
                                            }
                                            d.depositosup = d.depositosup - galconsu1di;
                                            c.gax2csup = c.gax2csup + galconsu1di;
                                            c.consudi2sup = c.consudi2sup + consudin1d;
                                            Console.WriteLine("Usted compro " + galconsu1di + " galones");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back5;
                                        }
                                        else
                                        {
                                            Console.WriteLine("opcion invalida");
                                            Console.Clear();
                                            goto back5;
                                        }//final case super

                                    case 4:
                                        Console.Clear();
                                        goto back3;

                                }
                                break;//final case bomba 2
                            case 4://case bomba 3
                                int st4;
                            back7:
                                Console.WriteLine("Los precios de cada combustible son");
                                Console.WriteLine("Disiel " + c.preciodefidis + " por galon");
                                Console.WriteLine("Regular " + c.preciodefireg + " por galon");
                                Console.WriteLine("Super " + c.preciodefisup + " por galon");
                                Console.WriteLine("Los depositos cuentan con: ");
                                Console.WriteLine(d.depositodi + " galones de disiel");
                                Console.WriteLine(d.depositoreg + " galones de regular");
                                Console.WriteLine(d.depositosup + " galones de super");
                                m1.bom();
                                st4 = Convert.ToInt32(Console.ReadLine());
                                switch (st4) //inicio 2 sub case
                                {
                                    case 1:// case disiel      
                                        int resp;
                                        m1.comopagar();
                                        resp = Convert.ToInt32(Console.ReadLine());
                                        if (resp == 1)//all descision de comprar por galones
                                        {
                                            int compra1dise = 0;
                                            double gasto1dise = 0;
                                            Console.WriteLine("Cuantos galones desea comprar");
                                            compra1dise = Convert.ToInt32(Console.ReadLine());
                                            if (compra1dise > d.depositodi)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con es cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back7;
                                            }
                                            c.tg4d = c.tg4d + compra1dise;//guarda constanemten total gastado galones de disel bomba1
                                            d.depositodi = d.depositodi - compra1dise;
                                            gasto1dise = compra1dise * c.preciodefidis;
                                            c.ga4d = c.ga4d + gasto1dise;
                                            Console.WriteLine("Usted gasto " + gasto1dise + " quetzales");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back7;
                                        }
                                        if (resp == 2)//condicion sid desea consumir por dinero
                                        {
                                            double consudin1d, galconsu1di;// consumo por dinero bomba 1 disel y galones consumidos de disel 
                                            Console.WriteLine("Cuanto desea gastar");
                                            consudin1d = Convert.ToDouble(Console.ReadLine());
                                            galconsu1di = consudin1d / c.preciodefidis;
                                            
                                            if (galconsu1di > d.depositodi)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con esa cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back7;
                                            }
                                            d.depositodi = d.depositodi - galconsu1di;
                                            c.gax4cdis = c.gax4cdis + galconsu1di;
                                            c.con4sudidis = c.con4sudidis + consudin1d;
                                            Console.WriteLine("Usted compro " + galconsu1di + " galones");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back7;
                                        }
                                        else
                                        {
                                            Console.WriteLine("opcion invalida");
                                            Console.Clear();
                                            goto back7;
                                        }//final case disiel


                                    case 2:// case regu     
                                        int resp2;
                                        m1.comopagar();
                                        resp2 = Convert.ToInt32(Console.ReadLine());
                                        if (resp2 == 1)//all descision de comprar por galones
                                        {
                                            int compra1dise = 0;
                                            double gasto1dise = 0;
                                            Console.WriteLine("Cuantos galones desea comprar");
                                            compra1dise = Convert.ToInt32(Console.ReadLine());
                                            if (compra1dise > d.depositoreg)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con es cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back7;
                                            }
                                            c.tg4r = c.tg4r + compra1dise;
                                            d.depositoreg = d.depositoreg - compra1dise;
                                            gasto1dise = compra1dise * c.preciodefisup;
                                            c.ga4r = c.ga4r + gasto1dise;
                                            Console.WriteLine("Usted gasto " + gasto1dise + " quetzales");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back7;
                                        }
                                        if (resp2 == 2)//condicion sid desea consumir por dinero
                                        {
                                            double consudin1d = 0;
                                            double galconsu1di = 0;// consumo por dinero bomba 1 disel y galones consumidos de disel 
                                            Console.WriteLine("Cuanto desea gastar");
                                            consudin1d = Convert.ToDouble(Console.ReadLine());
                                            galconsu1di = consudin1d / c.preciodefireg;
                                            
                                            if (galconsu1di > d.depositoreg)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con esa cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back7;
                                            }
                                            d.depositoreg = d.depositoreg - galconsu1di;
                                            c.gax4creg = c.gax4creg + galconsu1di;
                                            c.consudi4reg = c.consudi4reg + consudin1d;
                                            Console.WriteLine("Usted compro " + galconsu1di + " galones");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back7;
                                        }
                                        else
                                        {
                                            Console.WriteLine("opcion invalida");
                                            Console.Clear();
                                            goto back7;
                                        }//final case regu
                                    case 3:// case super    
                                        int resp3;
                                        m1.comopagar();
                                        resp3 = Convert.ToInt32(Console.ReadLine());
                                        if (resp3 == 1)//all descision de comprar por galones
                                        {
                                            int compra1dise = 0;
                                            double gasto1dise = 0;
                                            Console.WriteLine("Cuantos galones desea comprar");
                                            compra1dise = Convert.ToInt32(Console.ReadLine());
                                            if (compra1dise > d.depositosup)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con es cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back7;
                                            }
                                            c.tg4s = c.tg4s + compra1dise;
                                            d.depositosup = d.depositosup - compra1dise;
                                            gasto1dise = compra1dise * c.preciodefisup;
                                            c.ga4s = c.ga4s + gasto1dise;
                                            Console.WriteLine("Usted gasto " + gasto1dise + " quetzales");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back7;
                                        }
                                        if (resp3 == 2)//condicion sid desea consumir por dinero
                                        {
                                            double consudin1d = 0;
                                            double galconsu1di = 0;// consumo por dinero bomba 1 disel y galones consumidos de disel 
                                            Console.WriteLine("Cuanto desea gastar");
                                            consudin1d = Convert.ToDouble(Console.ReadLine());
                                            galconsu1di = consudin1d / c.preciodefisup;
                                       
                                            if (galconsu1di > d.depositosup)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con esa cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back7;
                                            }
                                            d.depositosup = d.depositosup - galconsu1di;
                                            c.gax4csup = c.gax4csup + galconsu1di;
                                            c.consudi4sup = c.consudi4sup + consudin1d;
                                            Console.WriteLine("Usted compro " + galconsu1di + " galones");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back7;
                                        }
                                        else
                                        {
                                            Console.WriteLine("opcion invalida");
                                            Console.Clear();
                                            goto back7;
                                        }//final case super

                                    case 4:
                                        Console.Clear();
                                        goto back3;





                                }
                                break;//final case bomba 3
                            case 3://case bomba 3
                                int st3;
                            back6:
                                Console.WriteLine("Los precios de cada combustible son");
                                Console.WriteLine("Disiel " + c.preciodefidis + " por galon");
                                Console.WriteLine("Regular " + c.preciodefireg + " por galon");
                                Console.WriteLine("Super " + c.preciodefisup + " por galon");
                                Console.WriteLine("Los depositos cuentan con: ");
                                Console.WriteLine(d.depositodi + " galones de disiel");
                                Console.WriteLine(d.depositoreg + " galones de regular");
                                Console.WriteLine(d.depositosup + " galones de super");
                                m1.bom();
                                st3 = Convert.ToInt32(Console.ReadLine());
                                switch (st3) //inicio 2 sub case
                                {
                                    case 1:// case disiel      
                                        int resp;
                                        m1.comopagar();
                                        resp = Convert.ToInt32(Console.ReadLine());
                                        if (resp == 1)//all descision de comprar por galones
                                        {
                                            int compra1dise = 0;
                                            double gasto1dise = 0;
                                            Console.WriteLine("Cuantos galones desea comprar");
                                            compra1dise = Convert.ToInt32(Console.ReadLine());
                                            if (compra1dise > d.depositodi)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con es cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back6;
                                            }
                                            c.tg3d = c.tg3d + compra1dise;//guarda constanemten total gastado galones de disel bomba1
                                            d.depositodi = d.depositodi - compra1dise;
                                            gasto1dise = compra1dise * c.preciodefidis;
                                            c.ga3d = c.ga3d + gasto1dise;
                                            Console.WriteLine("Usted gasto " + gasto1dise + " quetzales");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back6;
                                        }
                                        if (resp == 2)//condicion sid desea consumir por dinero
                                        {
                                            double consudin1d, galconsu1di;// consumo por dinero bomba 1 disel y galones consumidos de disel 
                                            Console.WriteLine("Cuanto desea gastar");
                                            consudin1d = Convert.ToDouble(Console.ReadLine());
                                            galconsu1di = consudin1d / c.preciodefidis;
                                           
                                            if (galconsu1di > d.depositodi)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con esa cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back6;
                                            }
                                            d.depositodi = d.depositodi - galconsu1di;
                                            c.gax3cdis = c.gax3cdis + galconsu1di;
                                            c.con3sudidis = c.con3sudidis + consudin1d;
                                            Console.WriteLine("Usted compro " + galconsu1di + " galones");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back6;
                                        }
                                        else
                                        {
                                            Console.WriteLine("opcion invalida");
                                            Console.Clear();
                                            goto back6;
                                        }//final case disiel


                                    case 2:// case regu     
                                        int resp2;
                                        m1.comopagar();
                                        resp2 = Convert.ToInt32(Console.ReadLine());
                                        if (resp2 == 1)//all descision de comprar por galones
                                        {
                                            int compra1dise = 0;
                                            double gasto1dise = 0;
                                            Console.WriteLine("Cuantos galones desea comprar");
                                            compra1dise = Convert.ToInt32(Console.ReadLine());
                                            if (compra1dise > d.depositoreg)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con es cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back6;
                                            }
                                            c.tg3r = c.tg3r + compra1dise;
                                            d.depositoreg = d.depositoreg - compra1dise;
                                            gasto1dise = compra1dise * c.preciodefireg;
                                            c.ga3r = c.ga3r + gasto1dise;
                                            Console.WriteLine("Usted gasto " + gasto1dise + " quetzales");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back6;
                                        }
                                        if (resp2 == 2)//condicion sid desea consumir por dinero
                                        {
                                            double consudin1d = 0;
                                            double galconsu1di = 0;// consumo por dinero bomba 1 disel y galones consumidos de disel 
                                            Console.WriteLine("Cuanto desea gastar");
                                            consudin1d = Convert.ToDouble(Console.ReadLine());
                                            galconsu1di = consudin1d / c.preciodefireg;
                                           
                                            if (galconsu1di > d.depositoreg)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con esa cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back6;
                                            }
                                            d.depositoreg = d.depositoreg - galconsu1di;
                                            c.gax3creg = c.gax3creg + galconsu1di;
                                            c.consudi3reg = c.consudi3reg + consudin1d;
                                            Console.WriteLine("Usted compro " + galconsu1di + " galones");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back6;
                                        }
                                        else
                                        {
                                            Console.WriteLine("opcion invalida");
                                            Console.Clear();
                                            goto back6;
                                        }//final case regu
                                    case 3:// case super    
                                        int resp3;
                                        m1.comopagar();
                                        resp3 = Convert.ToInt32(Console.ReadLine());
                                        if (resp3 == 1)//all descision de comprar por galones
                                        {
                                            int compra1dise = 0;
                                            double gasto1dise = 0;
                                            Console.WriteLine("Cuantos galones desea comprar");
                                            compra1dise = Convert.ToInt32(Console.ReadLine());
                                            if (compra1dise > d.depositosup)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con es cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back6;
                                            }
                                            c.tg3s = c.tg3s + compra1dise;
                                            d.depositosup = d.depositosup - compra1dise;
                                            gasto1dise = compra1dise * c.preciodefisup;
                                            c.ga3s = c.ga3s + gasto1dise;
                                            Console.WriteLine("Usted gasto " + gasto1dise + " quetzales");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back6;
                                        }
                                        if (resp3 == 2)//condicion sid desea consumir por dinero
                                        {
                                            double consudin1d = 0;
                                            double galconsu1di = 0;// consumo por dinero bomba 1 disel y galones consumidos de disel 
                                            Console.WriteLine("Cuanto desea gastar");
                                            consudin1d = Convert.ToDouble(Console.ReadLine());
                                            galconsu1di = consudin1d / c.preciodefisup;
                                            
                                            if (galconsu1di > d.depositosup)// condicion si no se cuenta con los galones en el deposito
                                            {
                                                Console.WriteLine("Lo sentimos no contamos con esa cantidad de combustible");
                                                Console.ReadLine();
                                                Console.Clear();
                                                goto back6;
                                            }
                                            d.depositosup = d.depositosup - galconsu1di;
                                            c.gax3csup = c.gax3csup + galconsu1di;
                                            c.consudi3sup = c.consudi3sup + consudin1d;
                                            Console.WriteLine("Usted compro " + galconsu1di + " galones");
                                            Console.WriteLine("Gracias por su compra");
                                            Console.ReadLine();
                                            Console.Clear();
                                            goto back6;
                                        }
                                        else
                                        {
                                            Console.WriteLine("opcion invalida");
                                            Console.Clear();
                                            goto back6;
                                        }//final case super

                                    case 4:
                                        Console.Clear();
                                        goto back3;

                                }
                                break;//final case bomba 4
                            case 5:
                                Console.Clear();
                                goto principal2;
                                


                        }
                    }
                    catch
                    {
                        
                            Console.WriteLine("opcion invalida");
                            Console.ReadLine();
                            Console.Clear();
                            goto back3;
                        

                    }

                    break; //final case cliente
                case 3:
                    Environment.Exit(0);
                        break;
                case 4:
                        c.Totaldegal1bomba = c.gax1cdis + c.gax1creg + c.gax1csup + c.tg1d + c.tg1r + c.tg1s;//calculo para el total de galones vendidos de cada bomba
                        c.Totaldegal2bomba = c.gax2cdis + c.gax2creg + c.gax2csup + c.tg2d + c.tg2r + c.tg2s;
                        c.Totaldegal3bomba = c.gax3cdis + c.gax3creg + c.gax3csup + c.tg3d + c.tg3r + c.tg3s;
                        c.Totaldegal4bomba = c.gax4cdis + c.gax4creg + c.gax4csup + c.tg4d + c.tg4r + c.tg4s;
                        c.vgalonestotalesdis = c.tg1d + c.tg2d + c.tg3d + c.tg4d + c.gax1cdis + c.gax2cdis + c.gax3cdis + c.gax4cdis;//galones vendidos de cada tipo de combustible
                        c.vgalonestotalesreg = c.tg1r + c.tg2r + c.tg3r + c.tg4r + c.gax1creg + c.gax2creg + c.gax3creg + c.gax4creg;
                        c.vgalonestotalesup = c.tg1s + c.tg2s + c.tg3s + c.tg4s + c.gax1csup + c.gax2csup + c.gax3csup + c.gax4csup;
                        c.ingresosdisiel=c.con1sudidis+c.con2sudidis+c.con3sudidis+ c.con4sudidis + c.ga1d+ c.ga2d+ c.ga3d +  c.ga4d;//ingreso de cada tipo de combustible
                        c.ingresosregular = c.consudi1reg + c.consudi2reg + c.consudi3reg + c.consudi4reg + c.ga1r + c.ga2r + c.ga3r + c.ga4r;
                       c.ingresossuper = c.consudi1sup + c.consudi2sup + c.consudi3sup + c.consudi4sup + c.ga1s + c.ga2s + c.ga3s + c.ga4s;
                        c.TotaldeInl1bomba = c.ga1d + c.ga1r + c.ga1s + c.con1sudidis + c.consudi1reg + c.consudi1sup;//total de ingresos por bombas
                        c.TotaldeInl2bomba = c.ga2d + c.ga2r + c.ga2s + c.con2sudidis + c.consudi2reg + c.consudi2sup;
                        c.TotaldeInl3bomba = c.ga3d + c.ga3r + c.ga3s + c.con3sudidis + c.consudi3reg + c.consudi3sup;
                        c.TotaldeInl4bomba = c.ga4d + c.ga4r + c.ga4s + c.con4sudidis + c.consudi4reg + c.consudi4sup;
                        Console.WriteLine("Los galones que vendio la primera bomba son "+c.Totaldegal1bomba);
                        Console.WriteLine("El ingreso de la primera bomba son " + c.TotaldeInl1bomba + " quetzales");
                        Console.WriteLine("Los galones que vendio la segunda a bomba son " + c.Totaldegal2bomba);
                        Console.WriteLine("El ingreso de la segunda bomba son " + c.TotaldeInl2bomba + " quetzales");
                        Console.WriteLine("Los galones que vendio la tercera a bomba son " + c.Totaldegal3bomba);
                        Console.WriteLine("El ingreso de la tercera bomba son " + c.TotaldeInl3bomba + " quetzales");
                        Console.WriteLine("Los galones que vendio la cuarta a bomba son " + c.Totaldegal4bomba);
                        Console.WriteLine("El ingreso de la cuarta bomba son " + c.TotaldeInl4bomba + " quetzales");
                        Console.WriteLine("");
                        Console.WriteLine("Los galones vendidos de disiel fueron "+c.vgalonestotalesdis);
                        Console.WriteLine("Los ingresos del disiel son "+c.ingresosdisiel+" quetzales");
                        Console.WriteLine("");
                        Console.WriteLine("Los galones vendidos de regular fueron "+c.vgalonestotalesreg);
                        Console.WriteLine("Los ingresos del regular son "+c.ingresosregular+" quetzales");
                        Console.WriteLine("");
                        Console.WriteLine("Los galones vendidos de super fueron "+c.vgalonestotalesup);
                        Console.WriteLine("Los ingresos de del super son "+c.ingresossuper+" quetzales");
                        Console.WriteLine("");
                        Console.WriteLine("Los galones comprados de disiel fueron " + c.ngd + " y se gasto " + c.totalgastd + " quetzales");
                        Console.WriteLine("Los galones comprados de regular fueron " + c.ngr + " y se gasto " + c.totalgastr + " quetzales");
                        Console.WriteLine("Los galones comprados de super fueron " + c.ngs + " y se gasto " + c.totalgasts + " quetzales");
                        //all calucula las ganancias
                        c.ganancias = (c.ingresosdisiel + c.ingresosregular + c.ingresossuper) - (c.totalgastd + c.totalgastr + c.totalgasts + c.costoid + c.costoir + c.costois);
                        if (c.ganancias<0)
                        {
                            Console.WriteLine("Usted no tuvo ganancias");
                        }
                        if (c.ganancias>0)
                        {
                            Console.WriteLine("Su ganancias fueron "+c.ganancias+" quetzales");
                        }
                        Console.ReadLine();
                        Console.Clear();
                        goto principal2;
                        





                     


                    
                    

            }

        }

    }

}                






             


      

        

            
   

